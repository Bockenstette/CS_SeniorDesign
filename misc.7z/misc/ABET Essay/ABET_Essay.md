
In regards to the social requirement, our project is aimed at enhancing the quality of life of people. The core aim of the application is to aid people in organizing and managing their personal belongings. With people continuing to amass many belonings, trying to keep trac ow hat is actualy owned becomes difficult. By creating an application to address this issue, two positive outcomes are obtained. First, the outcome of being being aware of what one owns for reasons such as insurance in cases of damage or theft, and also when moving. Secondly, it will aid in helping people to not make duplicate purchases when they are unsure if they already own something or not.

Our project has a direct impact on our professional development, but not necessarily a direct impact on our public reputation.  Any skills that we learn while working on our project help us develop professionally.  The public reputation of the group members will most likely not be affected unless we decide to create a mobile app and/or distribute our application outside of our team.  Two major parts of our project include a database and a user interface.  Therefore, at least one of our team members will need to have knowledge of database design and development.  Also, someone will need to have an understanding of user interfaces and implementing a good user experience.

As we are storing information about the users, security is a valid concern of ours. We need
a solution that makes sure the users information will not be leaked. Because of this, we
need to take into account which version of the app we decide to pursue. If web based, we need
to be sure that we are using up to date encryption. If we go with the application base, we 
need to make sure whatever information we store on the persons phone is inaccessible to outside
access. Overall our need is to make sure sensitive user information is kept in a secure way. 
What we choose to develop our project with will have to fit the constraints required by our 
security needs.

Our project has an inherent moral and ethical impact on other people as we are in interacting with other people’s data.  This data has the potential to both directly and indirectly impact someone’s life, and this responsibility should not be taken on lightly.  One possible ethical quandary is the act of selling user information to companies.  As our project deals with storing information on a user’s personal belongings there would inherently be a strong incentive for companies to try to obtain this data to target ads and products to customers.  There is also the possibility of this information falling into the hands of someone with bad intentions.  A criminal with the data we collect could know about all the valuables in a house and where they are before they decide to rob that house.  Some precautions that can be taken in order to prevent these possible events are the encryption, obfuscation, and anonymization of data in our possession. 
