The inventory project is about proving that what I've learned is worth it. It will be the final capstone to my college experience
that will showcase that I did indeed learn everything I needed to in order to succeed in my chosen field. It will be a challenge
as well. It will challenge me to produce a viable application wihtin a certain timeframe, proving to myself my own ability. This
project is about validation. Validation of all the time and money that I've spent being worth it in the end.

Three major courses stick out to me as being useful for this project: CS2011 - Computer Science 2, CS 4092 - Database Design and
Development. I start with CS2011 simply because it is the most important. There is no specific skill
CS2011 has endowed me with, instead it is the overall knowledge of how to approach problems and applying programing techniques to
solve them which is the foundation for all programming. Every line I write is generally influenced by CS2011 in some way or another.
With CS4092, as the inventory project will require a database foundation, the skills learned in this class will be invaluable.
Whether it is building good queries or crafting the database tables and links in a efficient manner, CS4092 will help immensely.

My Co-op experiences offer little to my project in the way of technical skills. My time as a research co-op under the Rozier
TrustLab resulted in no real notworthy skills, technical or otherwise. My time as a co-op within the Advanced Solutions group at
Siemens PLM offers more soft-skills like presenting and effectively communicating within a group environment. What I worked on,
AR/VR applications, has no real applicable skills for something like our invnetory project. I will be able to bring over general
practices of course, but no real identifiable skills.

My motivation for this project is to be able to use it. I have a real pressing need for an application that can be used to keep
track of the items I own. My fairly expensive hobby relies on my knowing which specific items I have in my collection, so I do
not waste money rebuying them accidentally. My approach to creating our application is to get the databse backend running
initially. Afterwards expand on that core into the features we desire. And finally move into refinement for aspects like the
UX of the application.

I expect the inventory application to provide two services. First, I expect it to provide a way to store information on items.
Secondly, the inventory application must have a way of managing the items held within it. With those I believe the inventory
application will be at at point that can be considered "done." Any other features added on past that point will be extras to
expand functionality. AS for how we will know if we did a good job, the anser is simple, will we want to use it? A few members
want to use this application themselves, myself included. If we do not want to use the application we developed, then we failed
as developers.