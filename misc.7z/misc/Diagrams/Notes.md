# Project Title: Inventory App
## Goal Statement: To create an app to store digitally a list of one's belongings

* The diagram uses i* notation, which can be found here: 
http://istar.rwth-aachen.de/tiki-index.php?page=Summary+of+i%2A+Notation