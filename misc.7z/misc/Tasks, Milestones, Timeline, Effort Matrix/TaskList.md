1. Explore application direction (web or application based).
    * Primary Team Member: Matt
2. Investigate what platform to use for back end.
    * Primary Team Member: Kevin
3. Investigate what framework to use for front end.
    * Primary Team Member: Ryan
4. Implement back end.
    * Primary Team Member: Kevin
5. Test back end.
    * Primary Team Member: Adam
6. Construct front end.
    * Primary Team Member: Ryan
7. Connect front end to back end.
    * Primary Team Member: Matt
8. Test combination of front and back end.
    * Primary Team Member: Adam
9. Choose encryption method.
    * Primary Team Member: Adam
10. Create user authentication.
    * Primary Team Member: Ryan
11. Refine user experience.
    * Primary Team Member: Matt
