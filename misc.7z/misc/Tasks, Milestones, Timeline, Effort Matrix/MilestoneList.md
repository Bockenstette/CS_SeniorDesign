1. Functional back end
	* The database back end of our project will be functional and tested.
2. Functional front end
	* The front end of our project will be functional and completed.
3. Front and back end integrated
	* The back end and front end of our project will be integrated and work together.
4. Final testing completed
	* All testing will be completed and all bugs found will be fixed.
5. Final version released
	* The final version of our project will be ready to present.