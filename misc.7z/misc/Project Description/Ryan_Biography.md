# Assignment 1 - CS Senior Design

## Professional Biography for Ryan Pavsek

## Contact information

pavsekrt@mail.uc.edu <br />
(440)223-5620

## Co-op Work Experience

#### Siemens PLM Software - LCS Coop
* Worked on an internal tool to increase productivity.
* Implemented a REST backend using Java, Tomcat, and Solr indexing, and a frontend using TypeScript and Angular 2.


## Project Sought

* Something I haven't done before, like machine learning or neural networks
* Hopfully a project in app or webapp form
